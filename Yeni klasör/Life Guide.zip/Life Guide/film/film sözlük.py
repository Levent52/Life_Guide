movie={"The Shawshank Redemption":"0111161","The Godfather":"0068646","The Dark Knight":"0468569",
       "The Lord of the Rings: The Return of the King":"0167260","Schindler's List":"0108052","The Godfather: Part II:0071562",
"12 Angry Men":"0050083","Pulp Fiction":"0110912","Inception":"1375666",
"The Lord of the Rings: The Two Towers":"0167261","Fight Club":"0137523","The Lord of the Rings: The Fellowship of the Ring":"0120737",
"Forrest Gump":"0109830",
"Il buono, il brutto, il cattivo":"0060196",
"Everything Everywhere All at Once":"6710474",
"The Matrix":"0133093",
"Goodfellas":"0099685",
"The Empire Strikes Back":"0080684",
"One Flew Over the Cuckoo's Nest":"0073486","Interstellar":"0816692",
"Cidade de Deus":"0317248",
"Sen to Chihiro no kamikakushi":"0245429",
"Saving Private Ryan":"0120815",
"The Green Mile":"0120689","La vita è bella":"0118799","Se7en":"0114369",
"Terminator 2: Judgment Day":"0103064","The Silence of the Lambs":"0102926",
"Star Wars":"0076759","Seppuku":"0056058","Original title: Shichinin no samurai":"0047478",
"It's a Wonderful Life":"0038650","Gisaengchung":"6751668",
"Whiplash":"2582802","Intouchables":"1675434","The Prestige":"0482571","The Departed":"0407887",
"The Pianist":"0253474","Gladiator":"0172495","American History X":"0120586","The departed":"0407887",
"The Prestige":"0482571","Casablanca":"0034583","Whiplash":"2582802","The Intouchables":"1675434","Modern Times":"0027977","Seppuku":"0056058","C'era una volta il West":"0064116",
"Hotaru no haka":"0095327","Rear Window":"0047396","Alien":"0078748","City Lights":"0021749","Nuovo Cinema Paradiso":"0095765","Memento":"0209144","Apocalypse Now":"0078788",
       "Everything Everywhere All at Once":"6710474",
       "Raiders of the Lost Ark":"0082971","Django Unchained":"1853728","WALL·E":"0910970","Das Leben der Anderen":"0405094","Sunset Blvd.":"0043014","Paths of Glory":"0050825",
       "The Shining":"0081505","The Great Dictator":"0032553","Witness for the Prosecution":"0051201","Avengers: Infinity War":"4154756",
"Das Leben der Anderen":"0405094",
"Das Boot":"0082096",
"Raiders of the Lost Ark":"0082971",
"Amadeus":"0086879",
"Aliens":"0090605",
"Braveheart"	*0112573
Mononoke-hime	*0119698
American Beauty	*0169547
Memento	*0209144
Oldeuboi	*0364569




       }
